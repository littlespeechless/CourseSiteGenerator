/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author zhengyu
 */
public class Schedule {
    private final StringProperty type;
    private final StringProperty date;
    private final StringProperty title;
    private final StringProperty topic;
    private final StringProperty link;

    
    public Schedule(String initType, String initDate, String initTitle, 
            String initTopic, String initLink){
        type = new SimpleStringProperty(initType);
        date = new SimpleStringProperty(initDate);
        title = new SimpleStringProperty(initTitle);
        topic = new SimpleStringProperty(initTopic);
        link= new SimpleStringProperty(initLink);
    }
    public String getType(){
        return type.getValue();
    }
    public void setType(String initType){
        type.set(initType);
    }
    public StringProperty typeProperty(){
        return type;
    }
    public String getDate(){
        return date.getValue();
    }
    public void setDate(String initDate){
        date.set(initDate);
    }
    public StringProperty dateProperty(){
        return date;
    }
   
    public String getTitle(){
        return title.getValue();
    }
    public void setTitle(String initTitle){
        title.set(initTitle);
    }
    public StringProperty titleProperty(){
        return title;
    }
    public String getTopic(){
        return topic.getValue();
    }
    public void setTopic(String initTopic ){
        topic.set(initTopic);
    }
    public StringProperty topicProperty(){
        return topic;
    }    
    public String getLink(){
        return link.getValue();
    }
    public void setLink(String initLink){
        link.set(initLink);
    }
    public StringProperty linkProperty(){
        return link;
    }   
    
}
