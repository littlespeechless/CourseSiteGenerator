/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csg.data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author zhengyu
 */
public class Lecture {
    private final StringProperty section;
    private final StringProperty days;
    private final StringProperty time;
    private final StringProperty room;
    
    public Lecture(String initSection, String initDays, String initTimes, 
            String initRoom){
        section = new SimpleStringProperty(initSection);
        days = new SimpleStringProperty(initDays);
        time = new SimpleStringProperty(initTimes);
        room = new SimpleStringProperty(initRoom);
    }
    public String getSection(){
        return section.get();
    }
    public void setSection(String initSection){
        section.set(initSection);
    }
    public StringProperty sectionProperty(){
        return section;
    }
    public String getDays(){
        return days.get();
    }
    public void setDays(String initDays){
        days.set(initDays);
    }
    public StringProperty daysProperty(){
        return days;
    }
    public String getTime(){
        return time.get();
    }
    public void setTime(String initTime){
        time.set(initTime);
    }
    public StringProperty timeProperty(){
        return time;
    }
    public String getRoom(){
        return room.get();
    }
    public void setRoom(String initRoom){
        room.set(initRoom);
    }
    public StringProperty roomProperty(){
        return room;
    }    
    
}
