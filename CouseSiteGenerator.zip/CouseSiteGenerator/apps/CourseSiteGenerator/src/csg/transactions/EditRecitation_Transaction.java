package csg.transactions;

import csg.data.CourseSiteData;
import csg.data.Recitation;
import csg.data.TeachingAssistantPrototype;
import jtps.jTPS_Transaction;


/**
 *
 * @author McKillaGorilla
 */
public class EditRecitation_Transaction implements jTPS_Transaction {
    CourseSiteData data;
    Recitation recitation;
    String oldSection;
    String oldDaysTime;
    String oldRoom;
    String oldTA1;
    String oldTA2;
    String newSection;
    String newDaysTime;
    String newRoom;
    String newTA1;
    String newTA2;
    
    public EditRecitation_Transaction(CourseSiteData initData, 
            Recitation initRecitation, String initSection, String initDaysTime,
            String initRoom, String initTA1,String initTA2) {
        data = initData;
        recitation = initRecitation;
        newSection = initSection;
        newDaysTime = initDaysTime;
        newRoom = initRoom;
        newTA1 = initTA1;
        newTA2 = initTA2;
        oldSection = recitation.getSection();
        oldDaysTime = recitation.getDaysTime();
        oldRoom = recitation.getRoom();
        oldTA1 = recitation.getTa1();
        oldTA2 = recitation.getTa2();
    }

    @Override
    public void doTransaction() {
        data.editRecitation(newSection, newDaysTime, newRoom, newTA1, newTA2, recitation);
    }

    @Override
    public void undoTransaction() {
        data.editRecitation(oldSection, oldDaysTime, oldRoom, oldTA1, oldTA2, recitation);
    }
}
