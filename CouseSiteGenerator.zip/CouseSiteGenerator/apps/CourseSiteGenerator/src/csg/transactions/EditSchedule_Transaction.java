package csg.transactions;

import csg.data.CourseSiteData;
import csg.data.Lab;
import csg.data.Recitation;
import csg.data.Schedule;
import csg.data.TeachingAssistantPrototype;
import jtps.jTPS_Transaction;


/**
 *
 * @author McKillaGorilla
 */
public class EditSchedule_Transaction implements jTPS_Transaction {
    CourseSiteData data;
    Schedule schedule;
    String oldType;
    String oldDate;
    String oldTitle;
    String oldTopic;
    String oldLink;
    String newType;
    String newDate;
    String newTitle;
    String newTopic;
    String newLink;
    
    public EditSchedule_Transaction(CourseSiteData initData, 
            Schedule initSchedule, String initType, String initDate,
            String initTitle, String initTopic,String initLink) {
        data = initData;
        schedule = initSchedule;
        newType = initType;
        newDate= initDate;
        newTitle = initTitle;
        newTopic = initTopic;
        newLink = initLink;
        oldType = schedule.getType();
        oldDate = schedule.getDate();
        oldTitle = schedule.getTitle();
        oldTopic = schedule.getTopic();
        oldLink = schedule.getLink();
    }

    @Override
    public void doTransaction() {
        data.editSchedule(newType, newDate, newTitle, newTopic, newLink, schedule);
    }

    @Override
    public void undoTransaction() {
        data.editSchedule(oldType, oldDate, oldTitle, oldTopic, oldLink, schedule);
    }
}
